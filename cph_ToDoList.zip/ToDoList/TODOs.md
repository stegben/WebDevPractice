## Necessary:
1. Static HTML, CSS, JS
2. GA

## optional:
1. create a server to store
2. Client-side renderer
3. D3
